import React from 'react';
import ItemList from './Component';

// import './App.css';

function App() {
  return (
    <div className="App">
    <ItemList/> 
    </div>
  );
}

export default App;
