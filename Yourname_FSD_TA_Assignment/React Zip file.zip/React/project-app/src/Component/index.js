import React, { useEffect, useState } from 'react';
import axios from 'axios'; // for fetching API from backend to frontend

// for state managent , useState use
const ItemList = () => {
const [items, setItems] = useState([]);
const [loading, setLoading] = useState(true);
const [error, setError] = useState(null);

// useEfftect is for data fetching
useEffect(() => {
    const fetchItems = async () =>{
        try {
            const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
            setItems(response.data);
        } catch (err) {
            setError('Failed to fetch items');
        } finally {
            setLoading(false);
        }  
    };
    fetchItems();
}, []);
if (loading) return <div> Please wait while it Loading</div>;
if(error) return <div>Something went wrong. Please recheck</div>;

// JSX are written here by using map we write it 
return(
    <div>
    <h1>Items List</h1>
    <ul>
        {items.map(item => (
            <li key={item.id}>
                <h2>{item.title}</h2>
                <p>{item.body}</p>
            </li>
        ))}
    </ul>
</div> 
);

};

export default ItemList;